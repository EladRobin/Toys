import React, { useEffect, useState } from 'react'
import axios from "axios";
import "./Api.css"
import Toy from './Toy';
const Api = () => {
    const [toys, setToys] = useState([]);
    useEffect(() => {
        getToys();
    }, [])

    const getToys = async () => {
        const { data } = await axios.get("https://toys-domain.herokuapp.com/toys");
        setToys(data)
    }

    return (
        <div className='myContainer'>
            <div className='row'>
                {
                   toys.map(item=><Toy setToys={setToys} toys={toys} key={item._id} item={item}/>) 
                }
            </div>
        </div>
    )
}

export default Api