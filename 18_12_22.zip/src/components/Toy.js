import React from 'react'
import "./Api.css"
const Toy = ({ item, setToys, toys }) => {
    const removeItem = () => {
        let toysAr = toys.filter(element => element._id != item._id)
        setToys(toysAr)
    }
    return (
        <div className='col-md-3 col-sm-6 p-3 '>
            <div onClick={removeItem} className='shadow toy'>
                <div className='delete'>x</div>
                <div className='imag' style={{ backgroundImage: `url(${item.img_url})` }}></div>
                <div className='p-1'>
                    <h5>{item.name}</h5>
                    <h6>price: {item.price} ils</h6>
                </div>
            </div>
        </div>
    )
}

export default Toy