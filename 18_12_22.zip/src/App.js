import Api from "./components/Api";
import "./learnJs"
function App() {
  return (
    <>
      <Api />
    </>
  );
}

export default App;
